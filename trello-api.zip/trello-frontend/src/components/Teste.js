
const Teste = () => {
  // Apenas para testar a importação
  return <div>Teste de Importação</div>;
};

export default Teste;
