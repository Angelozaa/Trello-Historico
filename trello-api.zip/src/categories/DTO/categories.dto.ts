export class CategoryDTO {
    name: string
    description: string
    isActive: boolean
}